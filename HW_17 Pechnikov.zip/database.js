const DATABASE = [
    {
        id: 1001,
        title: 'USB хаб LAPARA LA-SLED4 White 4-port',
        image: 'https://i.can.ua/images/200x190/goods/705/705024.jpg',
        price: 107.0,
        description: 'some text about something'
    },
    {
        id: 1002,
        title: 'Соединитель витой пары ATCOM 11445',
        image: 'https://i.can.ua/images/200x190/goods/1818/1818830.jpg',
        price: 25.0,
        description: 'some text about something'
    },
    {
        id: 1003,
        title: 'Повербанк BASEUS Thin Digital Black 10000mAh (PPYZ-C01)',
        image: 'https://i.can.ua/images/200x190/goods/5647/5647988.jpg',
        price: 449.0,
        description: 'some text about something'
    },
    {
        id: 1004,
        title: 'Блок питания 500W GAMEMAX Eco GM-500B',
        image: 'https://i.can.ua/images/200x190/goods/1274/1274489.jpg',
        price: 669.0,
        description: 'some text about something'
    },
    {
        id: 1005,
        title: 'Видеокарта MSI GeForce RTX 3090 Suprim X 24G',
        image: 'https://i.can.ua/images/200x190/goods/7696/7696162.jpg',
        price: 112759.0,
        description: 'some text about something'
    },
    {
        id: 1006,
        title: 'Мышь 2E MF216 WL (2E-MF216WB)',
        image: 'https://i.can.ua/images/200x190/goods/8306/8306536.jpg',
        price: 189.0,
        description: 'some text about something'
    },
];